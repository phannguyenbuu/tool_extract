from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, Tuple

from flask import Flask, jsonify, request, send_from_directory, send_file
import numpy as np
import xml.etree.ElementTree as ET

import new_toy

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "frontend"
DIST_DIR = WEB_DIR / "dist"
STATE_JSON = ROOT / "ui_state.json"
STATE_SVG = ROOT / "ui_state.svg"
PACK_LABELS = ROOT / "packed_labels.json"
LAST_RENDER_PARAMS: Dict[str, Any] = {}
SVG_PATH = ROOT / "convoi.svg"
SVG_BACKUP = ROOT / "convoi_backup.svg"

app = Flask(__name__, static_folder=None)


def ensure_outputs() -> None:
    env = os.environ.copy()
    env["INTERSECT_SNAP"] = str(new_toy.INTERSECT_SNAP)
    env["LINE_EXTEND"] = str(new_toy.LINE_EXTEND)
    env["RASTER_ONLY"] = "1"
    cmd = [os.fspath(Path(os.environ.get("PYTHON", "python"))), os.fspath(ROOT / "new_toy.py")]
    subprocess.run(cmd, cwd=ROOT, env=env, check=False)

def _apply_params(payload: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
    snap = float(payload.get("snap", new_toy.INTERSECT_SNAP))
    for key, env_key in (
        ("pack_padding", "PACK_PADDING"),
        ("pack_margin_x", "PACK_MARGIN_X"),
        ("pack_margin_y", "PACK_MARGIN_Y"),
        ("pack_bleed", "PACK_BLEED"),
        ("pack_grid", "PACK_GRID_STEP"),
        ("pack_angle", "PACK_ANGLE_STEP"),
        ("pack_mode", "PACK_MODE"),
    ):
        if key in payload:
            os.environ[env_key] = str(payload[key])
    os.environ["INTERSECT_SNAP"] = str(snap)
    new_toy._apply_pack_env()
    return snap, payload



@app.get("/api/scene")
def api_scene():
    try:
        snap = float(LAST_RENDER_PARAMS.get("snap", new_toy.INTERSECT_SNAP))
        for key, env_key in (
            ("pack_padding", "PACK_PADDING"),
            ("pack_margin_x", "PACK_MARGIN_X"),
            ("pack_margin_y", "PACK_MARGIN_Y"),
            ("pack_bleed", "PACK_BLEED"),
            ("pack_grid", "PACK_GRID_STEP"),
            ("pack_angle", "PACK_ANGLE_STEP"),
            ("pack_mode", "PACK_MODE"),
        ):
            if key in LAST_RENDER_PARAMS:
                os.environ[env_key] = str(LAST_RENDER_PARAMS[key])
        os.environ["INTERSECT_SNAP"] = str(snap)
        data = new_toy.compute_scene(new_toy.SVG_PATH, snap)
        return jsonify(data)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/step/regions")
def api_step_regions():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    try:
        snap, _ = _apply_params(payload)
        _, polys, canvas, _ = new_toy.build_regions_from_svg(new_toy.SVG_PATH, snap_override=snap)
        return jsonify({"canvas": {"w": canvas[0], "h": canvas[1]}, "regions": polys})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/step/zones")
def api_step_zones():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    try:
        snap, _ = _apply_params(payload)
        _, polys, canvas, _ = new_toy.build_regions_from_svg(new_toy.SVG_PATH, snap_override=snap)
        zone_id = new_toy.build_zones(polys, new_toy.TARGET_ZONES)
        zone_boundaries = new_toy.build_zone_boundaries(polys, zone_id)
        zone_geoms = new_toy.build_zone_geoms(polys, zone_id)
        zone_ids = sorted(zone_geoms.keys())
        rng = np.random.default_rng(42)
        shuffled = zone_ids.copy()
        rng.shuffle(shuffled)
        zone_label_map = {z: idx + 1 for idx, z in enumerate(shuffled)}
        zone_labels = {}
        for zid in zone_geoms:
            lx, ly = new_toy._label_pos_largest_region(polys, zone_id, zid)
            zone_labels[str(zid)] = {"x": lx, "y": ly, "label": zone_label_map.get(zid, zid)}
        region_colors = None
        if payload.get("zone_images"):
            raw_colors, _ = new_toy.compute_region_colors(polys, canvas)
            region_colors = [f"#{r:02x}{g:02x}{b:02x}" for (b, g, r) in raw_colors]
        return jsonify(
            {
                "canvas": {"w": canvas[0], "h": canvas[1]},
                "zone_id": zone_id,
                "zone_boundaries": zone_boundaries,
                "zone_labels": zone_labels,
                "region_colors": region_colors,
            }
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/step/pack")
def api_step_pack():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    try:
        snap, _ = _apply_params(payload)
        data = new_toy.compute_scene(new_toy.SVG_PATH, snap)
        return jsonify(
            {
                "canvas": data.get("canvas"),
                "packed_zone_polys": data.get("packed_zone_polys"),
                "packed_labels": data.get("packed_labels"),
                "packed_polys": data.get("packed_polys"),
                "packed_colors": data.get("packed_colors"),
                "packed_bleed_polys": data.get("packed_bleed_polys"),
                "packed_bleed_colors": data.get("packed_bleed_colors"),
                "debug": data.get("debug"),
            }
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/render")
def api_render():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    LAST_RENDER_PARAMS.clear()
    LAST_RENDER_PARAMS.update(payload)
    snap = float(payload.get("snap", new_toy.INTERSECT_SNAP))
    env = os.environ.copy()
    env["INTERSECT_SNAP"] = str(snap)
    env["LINE_EXTEND"] = str(new_toy.LINE_EXTEND)
    env["RASTER_ONLY"] = "1"
    for key, env_key in (
        ("pack_padding", "PACK_PADDING"),
        ("pack_margin_x", "PACK_MARGIN_X"),
        ("pack_margin_y", "PACK_MARGIN_Y"),
        ("pack_bleed", "PACK_BLEED"),
        ("pack_grid", "PACK_GRID_STEP"),
        ("pack_angle", "PACK_ANGLE_STEP"),
        ("pack_mode", "PACK_MODE"),
    ):
        if key in payload:
            env[env_key] = str(payload[key])
    cmd = [os.fspath(Path(os.environ.get("PYTHON", "python"))), os.fspath(ROOT / "new_toy.py")]
    proc = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        return jsonify({"ok": False, "error": proc.stderr.strip()}), 500
    return jsonify({"ok": True})


@app.post("/api/state")
def api_state():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    STATE_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # build a lightweight svg for fast restore
    canvas = payload.get("canvas", {})
    w = canvas.get("w", 1000)
    h = canvas.get("h", 1000)
    paths = []
    for region in payload.get("regions", []):
        if not region:
            continue
        d = "M " + " L ".join(f"{p[0]} {p[1]}" for p in region) + " Z"
        paths.append(f'<path d="{d}" fill="none" stroke="#999" stroke-width="0.5"/>')
    labels = []
    for lbl in payload.get("labels", []):
        labels.append(
            f'<text x="{lbl["x"]}" y="{lbl["y"]}" font-size="6" fill="#000">{lbl["label"]}</text>'
        )

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
        f'viewBox="0 0 {w} {h}">'
        + "".join(paths)
        + "".join(labels)
        + "</svg>"
    )
    STATE_SVG.write_text(svg, encoding="utf-8")
    return jsonify({"ok": True})


@app.get("/api/pack_labels")
def api_pack_labels_get():
    try:
        if not PACK_LABELS.exists():
            return jsonify({})
        raw = PACK_LABELS.read_text(encoding="utf-8").strip()
        if not raw:
            return jsonify({})
        return jsonify(json.loads(raw))
    except Exception:
        return jsonify({})


@app.post("/api/pack_labels")
def api_pack_labels_set():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    PACK_LABELS.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return jsonify({"ok": True})


@app.post("/api/save_svg")
def api_save_svg():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    nodes = payload.get("nodes", [])
    segs = payload.get("segs", [])
    if not SVG_PATH.exists():
        return jsonify({"ok": False, "error": "convoi.svg not found"}), 404

    if not SVG_BACKUP.exists():
        SVG_BACKUP.write_bytes(SVG_PATH.read_bytes())

    tree = ET.parse(SVG_PATH)
    root = tree.getroot()

    # remove existing line/polyline/polygon (keep image)
    for parent in list(root.iter()):
        for child in list(parent):
            tag = child.tag.rsplit("}", 1)[-1]
            if tag in {"line", "polyline", "polygon"}:
                parent.remove(child)

    ns = {"svg": "http://www.w3.org/2000/svg"}
    g = ET.Element("g", {"id": "INTERACTIVE"})
    for seg in segs:
        try:
            a = nodes[seg[0]]
            b = nodes[seg[1]]
            line = ET.Element(
                "line",
                {
                    "x1": str(a["x"]),
                    "y1": str(a["y"]),
                    "x2": str(b["x"]),
                    "y2": str(b["y"]),
                    "stroke": "#000",
                    "stroke-width": "1",
                    "fill": "none",
                },
            )
            g.append(line)
        except Exception:
            continue
    root.append(g)

    tree.write(SVG_PATH, encoding="utf-8", xml_declaration=True)
    return jsonify({"ok": True})


@app.get("/")
def index():
    if DIST_DIR.exists():
        return send_from_directory(DIST_DIR, "index.html")
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/<path:path>")
def static_proxy(path: str):
    if DIST_DIR.exists() and (DIST_DIR / path).exists():
        return send_from_directory(DIST_DIR, path)
    return send_from_directory(WEB_DIR, path)


@app.get("/out/<path:path>")
def output_files(path: str):
    try:
        full_path = (ROOT / path).resolve()
        if not str(full_path).startswith(str(ROOT.resolve())):
            return ("not found", 404)
        if not full_path.exists():
            return ("not found", 404)
        return send_file(full_path)
    except Exception as exc:
        return (str(exc), 500)


if __name__ == "__main__":
    ensure_outputs()
    app.run(host="127.0.0.1", port=5000, debug=True)
